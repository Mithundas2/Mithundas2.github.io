import Layout from "../components/layout/layout.jsx";
import ProfileForm from "../components/user/Profile-Form.jsx";
const ProfilePage = () => {

    return (
        <Layout>
           <ProfileForm/>
        </Layout>
    );
};
export default ProfilePage;